# Sitio de inicio — pepecompagni.com

Este paquete contiene un `index.html` estático para publicar en Vercel.

## Pasos rápidos (GUI, sin terminal)

### 1) GitHub
1. Crea una cuenta (si no la tienes) y un repositorio **nuevo** llamado `pepecompagni-site` (público o privado).
2. Entra en el repo → **Add file → Upload files** y sube `index.html` (el de esta carpeta).
3. Pulsa **Commit changes**.

### 2) Vercel
1. Inicia sesión en https://vercel.com con tu cuenta de GitHub.
2. Pulsa **Add New… → Project → Import** tu repositorio `pepecompagni-site`.
3. Vercel detectará proyecto estático y lo desplegará. Obtendrás una URL temporal (p.ej. algo.vercel.app).

### 3) Conectar el dominio `pepecompagni.com`
1. En **Vercel → Project → Settings → Domains → Add**, añade **pepecompagni.com** y también **www.pepecompagni.com**.
2. Vercel te mostrará los **registros DNS exactos** que debes crear en Cloudflare. Copia/pega tal cual:
   - Suele pedir **CNAME** para `www` apuntando a `cname.vercel-dns.com`.
   - Para la raíz (`@`) puede pedir **CNAME** con *apex flattening* o un **A** (lo que te muestre).
3. En **Cloudflare → DNS → Records** crea esos registros. Recomendación: durante la verificación, ponlos como **DNS only** (nube gris).
4. Vuelve a Vercel y espera a que salga **Verified**. Marca **pepecompagni.com** como **Primary** para que `www` redirija.

### 4) Probar
- Abre `https://pepecompagni.com`. Deberías ver la página con tu título.
- Cambia el texto del `index.html`, súbelo a GitHub → Vercel publicará solo.

## Siguientes pasos
- Añadir páginas nuevas (otro `.html`) o pasar a un generador estático cuando quieras (Hugo/Eleventy/etc.).
- Insertar reproductor del podcast cuando tengas el trailer en Spotify/YouTube.
